﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="CalculationExtension_Sub.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   Part of Visual Studio ALM Rangers - Willy's Cave Dwelling Journals
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Microsoft.ALMRangers.Samples.CSharpFeatureTour.MEF.Shared
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.Composition;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    
    /// <summary>
    /// Subtraction Extension Sample
    /// </summary>
    [Export(typeof(ICalculation))]
    [ExportMetadata("Symbol", '-')]
    public class CalculationExtension_Sub : ICalculation
    {
        public long Calculation(long valueOne, long valueTwo)
        {
            // Intentional bug for HOL should be -
            return valueOne + valueTwo;
        }
    }
}
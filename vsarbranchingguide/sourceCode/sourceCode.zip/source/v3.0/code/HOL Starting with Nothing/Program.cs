﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="Program.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   Part of Visual Studio ALM Rangers - Willy's Cave Dwelling Journals
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Microsoft.ALMRangers.Samples.CSharpFeatureTour.MEF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.Composition;
    using System.ComponentModel.Composition.Hosting;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Microsoft.ALMRangers.Samples.CSharpFeatureTour.MEF.Shared;
    
    /// <summary>
    /// Main Program Class
    /// </summary>
    public class Program
    {
        // Import many potential calculators, with metadata
        [ImportMany]
        public IEnumerable<Lazy<ICalculation, ICalculationSymbol>> Calculations = null;

        // Extension container
        private CompositionContainer extensionContainer;

        /// <summary>
        /// Prevents a default instance of the <see cref="Program" /> class from being created.
        /// </summary>
        private Program()
        {
            // MEF catalog that can combine (aggregate) multiple catalogs
            var extensionCatalog = new AggregateCatalog();

            // Add our calculation catalog, whereby we are keeping all extensions in our own
            // assembly to keep this sample code simple. You can also (and probably should)
            // look outside your own assembly using the DirectoryCatalog
            extensionCatalog.Catalogs.Add(new AssemblyCatalog(typeof(Program).Assembly));

            // Create the container using our catalog
            this.extensionContainer = new CompositionContainer(extensionCatalog);

            // Fill the imports
            try
            {
                this.extensionContainer.ComposeParts(this);
            }
            catch (Exception ex)
            {
                // Really rudimentary error 
                Console.WriteLine("Problem in the Program constructor: ", ex.ToString());
            }
        }

        private static void Main(string[] args)
        {
            // Argument 1 = value 1
            // Argument 2 = value 2
            // Argument 3 = operand
            if (3 != args.Length)
            {
                Console.WriteLine("Rudimentary error handler: You must specifiy three " +
                                                    "arguments: value value operand, i.e. 1 1 +");
            }
            else
            {
                ////Console.WriteLine("{0} {1} {2} = Not implemented", args[0], args[2], args[1]);
                try
                {
                    Program program = new Program();
                    long valueOne = long.Parse(args[0]);
                    long valueTwo = long.Parse(args[1]);
                    char symbol = args[2][0];
                    string result = "ERROR! Calculation extension not found";

                    foreach (Lazy<ICalculation, ICalculationSymbol> calculator in program.Calculations)
                    {
                        if (calculator.Metadata.Symbol.Equals(symbol))
                        {
                            result = calculator.Value.Calculation(valueOne, valueTwo).ToString();
                            break;
                        }
                    }

                    // Display result
                    Console.WriteLine("{0} {1} {2} = {3}", args[0], args[2], args[1], result);
                }
                catch (Exception ex)
                {
                    // Really rudimentary error 
                    Console.WriteLine("Problem in Program Main when calling the extension: ", ex.ToString());
                }
            }

            Console.ReadLine();
        }
    }
}

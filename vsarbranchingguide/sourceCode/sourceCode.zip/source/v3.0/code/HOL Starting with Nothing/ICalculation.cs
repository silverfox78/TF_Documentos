﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="ICalculation.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   Part of Visual Studio ALM Rangers - Willy's Cave Dwelling Journals
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Microsoft.ALMRangers.Samples.CSharpFeatureTour.MEF.Shared
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    
    // Calculation interface
    public interface ICalculation
    {
        long Calculation(long valueOne, long valueTwo);
    }

    // Symbol interface
    public interface ICalculationSymbol
    {
        char Symbol { get; }
    }
}

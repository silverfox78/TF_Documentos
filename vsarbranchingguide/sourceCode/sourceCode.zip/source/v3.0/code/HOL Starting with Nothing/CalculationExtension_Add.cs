﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="CalculationExtension_Add.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   Part of Visual Studio ALM Rangers - Willy's Cave Dwelling Journals
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.Samples.CSharpFeatureTour.MEF.Shared
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.Composition;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    
    /// <summary>
    /// Addition Extension Sample
    /// </summary>
    [Export(typeof(ICalculation))]
    [ExportMetadata("Symbol", '+')]
    public class CalculationExtension_Add : ICalculation
    {
        /// <summary>
        /// Calculation method
        /// </summary>
        /// <param name="valueOne">Value one</param>
        /// <param name="valueTwo">Value two</param>
        /// <returns>Calculated value</returns>
        public long Calculation(long valueOne, long valueTwo)
        {
            return valueOne + valueTwo;
        }
    }
}
